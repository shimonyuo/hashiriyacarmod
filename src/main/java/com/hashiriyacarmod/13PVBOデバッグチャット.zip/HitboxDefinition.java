package com.hashiriyacarmod;

import net.minecraft.world.phys.Vec3;

/**
 * .jsonのhitboxで指定された8頂点をもとに、箱（台形も含む）の形を保持するクラスです。
 * ローカル座標（エンティティの原点を基準にした、回転前の座標）を持ち、
 * エンティティの位置・ヨー・ピッチ・ロールを反映したワールド座標へ変換する機能を持ちます。
 *
 * 「hitbox専用の回転オフセット」を持てるようにしてあります。これにより、
 * objモデルの見た目の向きとは完全に独立して、当たり判定の箱だけを
 * 好きな角度に固定で傾けておくことができます（例：ボックスにだけ+30度ロールをかける）。
 */
public class HitboxDefinition {

    private final Vec3[] localVertices;

    // ========== 追加：hitbox専用の固定回転オフセット ==========
    // これはエンティティ本体のyaw/pitch/rollとは別に、常にこの分だけ
    // 追加で箱を回転させるための値です。objモデル側には一切影響しません。
    private final float offsetYaw;
    private final float offsetPitch;
    private final float offsetRoll;

    private static final int[][] FACES = {
            {0, 1, 2, 3}, // 下面
            {7, 6, 5, 4}, // 上面
            {0, 4, 5, 1}, // 前面
            {1, 5, 6, 2}, // 右面
            {2, 6, 7, 3}, // 背面
            {3, 7, 4, 0}  // 左面
    };

    public HitboxDefinition(Vec3[] localVertices) {
        this(localVertices, 0f, 0f, 0f);
    }

    public HitboxDefinition(Vec3[] localVertices, float offsetYaw, float offsetPitch, float offsetRoll) {
        if (localVertices == null || localVertices.length != 8) {
            throw new IllegalArgumentException("hitboxのverticesは8個指定する必要があります");
        }
        this.localVertices = localVertices;
        this.offsetYaw = offsetYaw;
        this.offsetPitch = offsetPitch;
        this.offsetRoll = offsetRoll;
    }

    public static int[][] faces() {
        return FACES;
    }

    /**
     * エンティティの位置・ヨー・ピッチ・ロールに、hitbox専用オフセットを
     * 加算した上で、ワールド座標の8頂点を計算します。
     *
     * ここで加算するのはあくまで「箱の計算用の値」であり、
     * エンティティ本体のyaw/pitch/roll（＝objモデルの回転に使われる値）を
     * 書き換えたりはしません。
     */
    public Vec3[] toWorldVertices(double posX, double posY, double posZ,
                                  float yawDegrees, float pitchDegrees, float rollDegrees) {

        double roll  = Math.toRadians(rollDegrees + offsetRoll);
        double pitch = Math.toRadians(pitchDegrees + offsetPitch);
        double yaw   = Math.toRadians(yawDegrees + offsetYaw);

        Vec3[] result = new Vec3[8];
        for (int i = 0; i < 8; i++) {
            Vec3 v = localVertices[i];

            double x1 = v.x * Math.cos(roll) - v.y * Math.sin(roll);
            double y1 = v.x * Math.sin(roll) + v.y * Math.cos(roll);
            double z1 = v.z;

            double y2 = y1 * Math.cos(pitch) - z1 * Math.sin(pitch);
            double z2 = y1 * Math.sin(pitch) + z1 * Math.cos(pitch);
            double x2 = x1;

            double x3 = x2 * Math.cos(yaw) - z2 * Math.sin(yaw);
            double z3 = x2 * Math.sin(yaw) + z2 * Math.cos(yaw);
            double y3 = y2;

            result[i] = new Vec3(posX + x3, posY + y3, posZ + z3);
        }
        return result;
    }
}