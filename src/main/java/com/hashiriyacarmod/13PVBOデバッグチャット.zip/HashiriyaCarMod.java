package com.hashiriyacarmod;

import com.hashiriyacarmod.item.ModCreativeTabs;
import com.hashiriyacarmod.item.ModItems;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(HashiriyaCarMod.MOD_ID)
public class HashiriyaCarMod {

    public static final String MOD_ID = "hashiriyacarmod";

    public HashiriyaCarMod() {
        var eventBus = FMLJavaModLoadingContext.get().getModEventBus();

        // このModの固定アイテム・専用タブを登録します
        ModItems.register(eventBus);
        ModCreativeTabs.register(eventBus);

        CarPackLoader.initialize(FMLJavaModLoadingContext.get());
    }
}