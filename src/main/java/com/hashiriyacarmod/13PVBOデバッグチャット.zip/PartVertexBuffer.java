package com.hashiriyacarmod;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * 1パーツ分の頂点データを、GPU上に「項目ごとのかたまり」で保持するクラスです。
 *
 * 座標・色・UV・Overlay・明るさ・法線を、それぞれ独立したかたまりとして
 * 1本のバッファ内に並べます。どの項目も、変わった時はその項目のかたまりだけを
 * ピンポイントで書き換えます（他の項目は一切再送信しません）。
 *
 * バッファオブジェクト自体は最初に1回だけ作り、以後は同じ箱を使い回します。
 */
public class PartVertexBuffer implements AutoCloseable {

    // ---- 各項目のバイトサイズ（1頂点あたり） ----
    private static final int POS_SIZE     = 12; // float x3
    private static final int COLOR_SIZE   = 4;  // ubyte x4
    private static final int UV0_SIZE     = 8;  // float x2
    private static final int OVERLAY_SIZE = 4;  // short x2
    private static final int LIGHT_SIZE   = 4;  // short x2
    private static final int NORMAL_SIZE  = 4;  // byte x3 + パディング1

    // ---- attribute location（シェーダー側と要一致。仮に標準NEW_ENTITY順とする） ----
    private static final int LOC_POSITION = 0;
    private static final int LOC_COLOR    = 1;
    private static final int LOC_UV0      = 2;
    private static final int LOC_OVERLAY  = 3;
    private static final int LOC_LIGHT    = 4;
    private static final int LOC_NORMAL   = 5;

    private final int vao;
    private final int vbo;
    private final int ibo;
    private final int vertexCount;
    private final int indexCount;

    // ---- バッファ内での「かたまり」ごとの開始位置（オフセット） ----
    private final int offsetPos;
    private final int offsetColor;
    private final int offsetUv0;
    private final int offsetOverlay;
    private final int offsetLight;
    private final int offsetNormal;
    private final int totalSize;

    public PartVertexBuffer(ObjMesh mesh, int initialPackedLight) {
        this.vertexCount = mesh.vertexCount;
        this.indexCount = mesh.indexCount;

        this.offsetPos     = 0;
        this.offsetColor    = offsetPos     + vertexCount * POS_SIZE;
        this.offsetUv0      = offsetColor   + vertexCount * COLOR_SIZE;
        this.offsetOverlay  = offsetUv0     + vertexCount * UV0_SIZE;
        this.offsetLight    = offsetOverlay + vertexCount * OVERLAY_SIZE;
        this.offsetNormal   = offsetLight   + vertexCount * LIGHT_SIZE;
        this.totalSize      = offsetNormal  + vertexCount * NORMAL_SIZE;

        RenderSystem.assertOnRenderThread();
        this.vao = GlStateManager._glGenVertexArrays();
        this.vbo = GlStateManager._glGenBuffers();
        this.ibo = GlStateManager._glGenBuffers();

        GlStateManager._glBindVertexArray(vao);

        ByteBuffer buf = ByteBuffer.allocateDirect(totalSize).order(ByteOrder.nativeOrder());

        writePositionsInto(buf, offsetPos, mesh.posX, mesh.posY, mesh.posZ);
        writeColorInto(buf, offsetColor, 255, 255, 255, 255);
        writeUvInto(buf, offsetUv0, mesh.u, mesh.v);
        writeOverlayInto(buf, offsetOverlay);
        writeLightInto(buf, offsetLight, initialPackedLight);
        writeNormalsInto(buf, offsetNormal, mesh.nx, mesh.ny, mesh.nz);

        buf.rewind();

        GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        RenderSystem.glBufferData(GL15.GL_ARRAY_BUFFER, buf, GL15.GL_STATIC_DRAW);

        // ---------- attribute pointerの設定 ----------
        GL20.glVertexAttribPointer(LOC_POSITION, 3, GL20.GL_FLOAT, false, POS_SIZE, offsetPos);
        GL20.glEnableVertexAttribArray(LOC_POSITION);

        GL20.glVertexAttribPointer(LOC_COLOR, 4, GL20.GL_UNSIGNED_BYTE, true, COLOR_SIZE, offsetColor);
        GL20.glEnableVertexAttribArray(LOC_COLOR);

        GL20.glVertexAttribPointer(LOC_UV0, 2, GL20.GL_FLOAT, false, UV0_SIZE, offsetUv0);
        GL20.glEnableVertexAttribArray(LOC_UV0);

        org.lwjgl.opengl.GL30.glVertexAttribIPointer(LOC_OVERLAY, 2, GL20.GL_SHORT, OVERLAY_SIZE, offsetOverlay);
        GL20.glEnableVertexAttribArray(LOC_OVERLAY);

        org.lwjgl.opengl.GL30.glVertexAttribIPointer(LOC_LIGHT, 2, GL20.GL_SHORT, LIGHT_SIZE, offsetLight);
        GL20.glEnableVertexAttribArray(LOC_LIGHT);

        GL20.glVertexAttribPointer(LOC_NORMAL, 3, GL20.GL_BYTE, true, NORMAL_SIZE, offsetNormal);
        GL20.glEnableVertexAttribArray(LOC_NORMAL);

        // ---------- インデックスバッファ（形は固定なので1回だけ） ----------
        ByteBuffer idxBuf = ByteBuffer.allocateDirect(indexCount * 4).order(ByteOrder.nativeOrder());
        for (int idx : mesh.indices) idxBuf.putInt(idx);
        idxBuf.rewind();

        GlStateManager._glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, ibo);
        RenderSystem.glBufferData(GL15.GL_ELEMENT_ARRAY_BUFFER, idxBuf, GL15.GL_STATIC_DRAW);

        GlStateManager._glBindVertexArray(0);
    }

    // ==================== ピンポイント更新（それぞれ完全に独立） ====================

    /** 座標だけをピンポイントで書き換えます。色・UV・明るさ・法線には一切触れません。 */
    public void updatePositions(float[] posX, float[] posY, float[] posZ) {
        ByteBuffer buf = ByteBuffer.allocateDirect(vertexCount * POS_SIZE).order(ByteOrder.nativeOrder());
        writePositionsInto(buf, 0, posX, posY, posZ);
        buf.rewind();

        GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferSubData(GL15.GL_ARRAY_BUFFER, offsetPos, buf);
    }

    /** 色だけをピンポイントで書き換えます。座標・UV・明るさ・法線には一切触れません。 */
    public void updateColor(int r, int g, int b, int a) {
        ByteBuffer buf = ByteBuffer.allocateDirect(vertexCount * COLOR_SIZE).order(ByteOrder.nativeOrder());
        writeColorInto(buf, 0, r, g, b, a);
        buf.rewind();

        GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferSubData(GL15.GL_ARRAY_BUFFER, offsetColor, buf);
    }

    /** UVだけをピンポイントで書き換えます。座標・色・明るさ・法線には一切触れません。 */
    public void updateUV(float[] u, float[] v) {
        ByteBuffer buf = ByteBuffer.allocateDirect(vertexCount * UV0_SIZE).order(ByteOrder.nativeOrder());
        writeUvInto(buf, 0, u, v);
        buf.rewind();

        GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferSubData(GL15.GL_ARRAY_BUFFER, offsetUv0, buf);
    }

    /** Overlayだけをピンポイントで書き換えます（通常はNO_OVERLAY固定で十分ですが、念のため用意）。 */
    public void updateOverlay(int packedOverlay) {
        ByteBuffer buf = ByteBuffer.allocateDirect(vertexCount * OVERLAY_SIZE).order(ByteOrder.nativeOrder());
        short ou = (short) (packedOverlay & 0xFFFF);
        short ov = (short) (packedOverlay >> 16 & 0xFFFF);
        for (int i = 0; i < vertexCount; i++) {
            buf.putShort(i * OVERLAY_SIZE, ou);
            buf.putShort(i * OVERLAY_SIZE + 2, ov);
        }
        buf.rewind();

        GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferSubData(GL15.GL_ARRAY_BUFFER, offsetOverlay, buf);
    }

    /** 明るさだけをピンポイントで書き換えます。座標・色・UV・法線には一切触れません。 */
    public void updateLight(int packedLight) {
        ByteBuffer buf = ByteBuffer.allocateDirect(vertexCount * LIGHT_SIZE).order(ByteOrder.nativeOrder());
        writeLightInto(buf, 0, packedLight);
        buf.rewind();

        GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferSubData(GL15.GL_ARRAY_BUFFER, offsetLight, buf);
    }

    /** 法線だけをピンポイントで書き換えます。座標・色・UV・明るさには一切触れません。 */
    public void updateNormals(float[] nx, float[] ny, float[] nz) {
        ByteBuffer buf = ByteBuffer.allocateDirect(vertexCount * NORMAL_SIZE).order(ByteOrder.nativeOrder());
        writeNormalsInto(buf, 0, nx, ny, nz);
        buf.rewind();

        GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferSubData(GL15.GL_ARRAY_BUFFER, offsetNormal, buf);
    }

    // ==================== 書き込みヘルパー（初回一括書き込み／単体更新の両方から呼ばれる） ====================

    private void writePositionsInto(ByteBuffer buf, int base, float[] posX, float[] posY, float[] posZ) {
        for (int i = 0; i < vertexCount; i++) {
            int p = base + i * POS_SIZE;
            buf.putFloat(p,     posX[i]);
            buf.putFloat(p + 4, posY[i]);
            buf.putFloat(p + 8, posZ[i]);
        }
    }

    private void writeColorInto(ByteBuffer buf, int base, int r, int g, int b, int a) {
        for (int i = 0; i < vertexCount; i++) {
            int p = base + i * COLOR_SIZE;
            buf.put(p,     (byte) r);
            buf.put(p + 1, (byte) g);
            buf.put(p + 2, (byte) b);
            buf.put(p + 3, (byte) a);
        }
    }

    private void writeUvInto(ByteBuffer buf, int base, float[] u, float[] v) {
        for (int i = 0; i < vertexCount; i++) {
            int p = base + i * UV0_SIZE;
            buf.putFloat(p,     u[i]);
            buf.putFloat(p + 4, v[i]);
        }
    }

    private void writeOverlayInto(ByteBuffer buf, int base) {
        int noOverlay = net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY;
        short overlayU = (short) (noOverlay & 0xFFFF);
        short overlayV = (short) (noOverlay >> 16 & 0xFFFF);
        for (int i = 0; i < vertexCount; i++) {
            int p = base + i * OVERLAY_SIZE;
            buf.putShort(p,     overlayU);
            buf.putShort(p + 2, overlayV);
        }
    }

    private void writeLightInto(ByteBuffer buf, int base, int packedLight) {
        short u2 = (short) (packedLight & 0xFFFF);
        short v2 = (short) (packedLight >> 16 & 0xFFFF);
        for (int i = 0; i < vertexCount; i++) {
            int p = base + i * LIGHT_SIZE;
            buf.putShort(p,     u2);
            buf.putShort(p + 2, v2);
        }
    }

    private void writeNormalsInto(ByteBuffer buf, int base, float[] nx, float[] ny, float[] nz) {
        for (int i = 0; i < vertexCount; i++) {
            int p = base + i * NORMAL_SIZE;
            buf.put(p,     floatToByteNormal(nx[i]));
            buf.put(p + 1, floatToByteNormal(ny[i]));
            buf.put(p + 2, floatToByteNormal(nz[i]));
            buf.put(p + 3, (byte) 0);
        }
    }

    private static byte floatToByteNormal(float v) {
        return (byte) Math.round(v * 127.0f);
    }

    public void draw() {
        GlStateManager._glBindVertexArray(vao);
        GlStateManager._glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, ibo);
        GL20.glDrawElements(GL20.GL_TRIANGLES, indexCount, GL20.GL_UNSIGNED_INT, 0);
        GlStateManager._glBindVertexArray(0);
    }

    @Override
    public void close() {
        RenderSystem.glDeleteBuffers(vbo);
        RenderSystem.glDeleteBuffers(ibo);
        GlStateManager._glDeleteVertexArrays(vao);
    }
}