package com.hashiriyacarmod.network;

import com.hashiriyacarmod.HashiriyaCarMod;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.network.simple.SimpleChannel;

/**
 * このModのネットワーク通信(サーバー↔クライアント間のパケット)を管理します。
 */
public class ModNetwork {

    private static final String PROTOCOL_VERSION = "1";

    public static final SimpleChannel CHANNEL = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(HashiriyaCarMod.MOD_ID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    private static int packetId = 0;

    public static void register() {
        // サーバー → クライアント:GUIを開く命令
        CHANNEL.registerMessage(
                packetId++,
                WrenchOpenGuiPacket.class,
                WrenchOpenGuiPacket::encode,
                WrenchOpenGuiPacket::decode,
                WrenchOpenGuiPacket::handle,
                java.util.Optional.of(NetworkDirection.PLAY_TO_CLIENT)
        );
    }

    /**
     * 指定したプレイヤー1人に、GUIを開く命令を送ります。
     * サーバー側から呼び出してください。
     */
    public static void sendOpenGuiToPlayer(ServerPlayer player) {
        CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), new WrenchOpenGuiPacket());
    }
}