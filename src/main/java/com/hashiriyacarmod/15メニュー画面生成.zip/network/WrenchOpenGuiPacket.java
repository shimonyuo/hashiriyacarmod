package com.hashiriyacarmod.network;

import com.hashiriyacarmod.client.WrenchGuiScreen;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

/**
 * サーバーからクライアントへ「GUIを開け」と伝えるパケットです。
 * 今は「開け」という命令だけで、追加データは持っていません。
 * 今後、「どの車のエンティティIDか」などをここに乗せることができます。
 */
public class WrenchOpenGuiPacket {

    public WrenchOpenGuiPacket() {}

    /** パケットをバイト列に書き出します(今は空)。 */
    public void encode(FriendlyByteBuf buf) {}

    /** バイト列からパケットを読み込みます(今は空)。 */
    public static WrenchOpenGuiPacket decode(FriendlyByteBuf buf) {
        return new WrenchOpenGuiPacket();
    }

    /** クライアント側でパケットを受け取った時の処理です。 */
    public void handle(Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(this::openGui);
        ctx.get().setPacketHandled(true);
    }

    @OnlyIn(Dist.CLIENT)
    private void openGui() {
        net.minecraft.client.Minecraft.getInstance().setScreen(new WrenchGuiScreen());
    }
}