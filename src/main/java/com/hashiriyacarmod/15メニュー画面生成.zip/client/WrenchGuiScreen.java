package com.hashiriyacarmod.client;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
/**
 * レンチで車のOBBを検知した時に開くGUI画面です。
 * バニラGUIと同じサイズ感で、固定位置にウィンドウを表示します。
 *
 * - ウィンドウサイズ：130x200 px
 * - ウィンドウ位置：画面左上から(10, 10)
 * - フォント：バニラ標準フォント（this.font）を使用
 * - 背景：濃度50%の黒
 * - マウス・キー操作：特定のものだけゲームに通す（WASD、Space、Shift、マウス移動）
 * - ESC で閉じます
 */
@OnlyIn(Dist.CLIENT)
public class WrenchGuiScreen extends Screen {
    // =============== ウィンドウのサイズ（ここで変更） ===============
    private static final int IMAGE_WIDTH = 130;
    private static final int IMAGE_HEIGHT = 200;
    // =============== ウィンドウの位置（画面左上からのオフセット） ===============
    private static final int WINDOW_X = 10; // 画面左から10ピクセル
    private static final int WINDOW_Y = 10; // 画面上から10ピクセル
    // ウィンドウの左上座標（init()で代入します）
    private int leftPos;
    private int topPos;
    public WrenchGuiScreen() {
        super(Component.literal("Wrench GUI"));
    }
    /**
     * このメソッドは画面が開かれるたびに呼ばれます。
     * ここでウィジェット（ボタンなど）の配置を行います。
     */
    @Override
    protected void init() {
        super.init();
        // 定数で指定した位置にウィンドウを配置します
        this.leftPos = WINDOW_X;
        this.topPos = WINDOW_Y;
        // ── ここに今後ボタンなどのウィジェットを追加します ──
        // 例: this.addRenderableWidget(new Button(this.leftPos + 10, this.topPos + 20, 100, 20, ...))
    }
    @Override
    public boolean isPauseScreen() {
        // シングルプレイでも一時停止しないようにします
        return false;
    }
    @Override
    public void render(GuiGraphics guiGraphics, int mouseX, int mouseY, float partialTick) {
        // ── ウィンドウの背景（濃度50%の黒い矩形）を描画 ──
        guiGraphics.fill(this.leftPos, this.topPos,
                this.leftPos + IMAGE_WIDTH, this.topPos + IMAGE_HEIGHT,
                0x80000000);
        // ── タイトル文字を描画（バニラ標準フォント使用） ──
        // ウィンドウ内の上部中央に配置します
        Component title = Component.literal("Wrench");
        int titleX = this.leftPos + (IMAGE_WIDTH - this.font.width(title)) / 2;
        int titleY = this.topPos + 8;
        guiGraphics.drawString(this.font, title, titleX, titleY, 0xFFFFFF);
        // ── テスト用の説明文を描画 ──
        Component testText = Component.literal("Car Modification");
        int textX = this.leftPos + (IMAGE_WIDTH - this.font.width(testText)) / 2;
        int textY = this.topPos + 30;
        guiGraphics.drawString(this.font, testText, textX, textY, 0xCCCCCC);
        // ── ここに今後のウィジェット（ボタンなど）が描画されます ──
        super.render(guiGraphics, mouseX, mouseY, partialTick);
    }
    /**
     * キー入力の処理
     *
     * キーの処理ルール：
     * - ESC → このGUIが処理（画面を閉じる）→ true を返す
     * - WASD、Space、Shift → ゲームに通す → false を返す
     * - その他のキー → このGUIが処理（何もしない）→ true を返す
     *
     * true = 「このGUIが処理した、ゲームは処理しないでください」
     * false = 「このGUIは処理しない、ゲームに通してください」
     */
    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        // ESC (キーコード 256) で画面を閉じます
        if (keyCode == 256) {
            this.onClose();
            return true; // このGUIが処理した
        }
        // ── ゲームプレイ用キーをゲームに通す ──
        // W(87), A(65), S(83), D(68) = 移動キー
        if (keyCode == 87 || keyCode == 65 || keyCode == 83 || keyCode == 68) {
            return false; // ゲームに通す
        }
        // Space(32) = ジャンプ
        if (keyCode == 32) {
            return false; // ゲームに通す
        }
        // Left Shift(340) / Right Shift(344) = スニーク
        if (keyCode == 340 || keyCode == 344) {
            return false; // ゲームに通す
        }
        // その他のキーはこのGUIが消費（何もしない）
        return true;
    }
    /**
     * キーが離された時の処理
     * WASD・Space・Shiftはゲームに通す必要がある
     */
    @Override
    public boolean keyReleased(int keyCode, int scanCode, int modifiers) {
        // WASD・Space・Shift の keyUp はゲームに通す
        if (keyCode == 87 || keyCode == 65 || keyCode == 83 || keyCode == 68 || // WASD
                keyCode == 32 || keyCode == 340 || keyCode == 344) { // Space, Shift
            return false; // ゲームに通す
        }
        return super.keyReleased(keyCode, scanCode, modifiers);
    }
    /**
     * マウス移動（視点移動）
     * マウスはゲームに通して視点を移動させます。
     */
    @Override
    public void mouseMoved(double mouseX, double mouseY) {
        // マウス移動はゲームに通す
        super.mouseMoved(mouseX, mouseY);
    }
    /**
     * マウスのスクロール
     * スクロールもゲームに通す
     */
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        // マウススクロールはゲームに通す
        return super.mouseScrolled(mouseX, mouseY, delta);
    }
    /**
     * マウスドラッグ（ウィンドウ外をドラッグしたら、ゲームに通す）
     */
    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        // ウィンドウ外のドラッグはゲームに通す
        if (mouseX < this.leftPos || mouseX > this.leftPos + IMAGE_WIDTH ||
                mouseY < this.topPos || mouseY > this.topPos + IMAGE_HEIGHT) {
            return false; // ゲームに通す
        }
        return super.mouseDragged(mouseX, mouseY, button, dragX, dragY);
    }
}