package com.hashiriyacarmod;

import com.mojang.blaze3d.platform.NativeImage;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.texture.DynamicTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;
import java.util.Map;

/**
 * 外部フォルダのPNGファイルをMinecraftのテクスチャとして登録・キャッシュする。
 * クライアント専用。
 */
@OnlyIn(Dist.CLIENT)
public class CarTextureManager {

    private static final Logger LOGGER = LogManager.getLogger(HashiriyaCarMod.MOD_ID);

    // baseName → ResourceLocation のキャッシュ
    // 失敗済みの場合は null をキャッシュして再試行を防ぐ
    private static final Map<String, ResourceLocation> cache = new HashMap<>();

    /**
     * baseNameに対応するテクスチャの ResourceLocation を返す。
     * 初回呼び出し時にPNGを読み込んでTextureManagerに登録する。
     * 失敗した場合や pngFile が null の場合は null を返す。
     */
    public static ResourceLocation getOrLoad(String baseName, File pngFile) {
        if (cache.containsKey(baseName)) {
            return cache.get(baseName); // 失敗済みの場合も null が返る
        }

        if (pngFile == null || !pngFile.exists()) {
            LOGGER.warn("[HashiriyaCarMod] テクスチャファイルが見つかりません: {}", baseName);
            cache.put(baseName, null);
            return null;
        }

        try (FileInputStream fis = new FileInputStream(pngFile)) {
            NativeImage image   = NativeImage.read(fis);
            DynamicTexture tex  = new DynamicTexture(image);
            ResourceLocation loc = new ResourceLocation(
                    HashiriyaCarMod.MOD_ID, "dynamic/" + baseName.toLowerCase());
            Minecraft.getInstance().getTextureManager().register(loc, tex);
            cache.put(baseName, loc);
            LOGGER.debug("[HashiriyaCarMod] テクスチャ登録完了: {}", loc);
            return loc;
        } catch (Exception e) {
            LOGGER.error("[HashiriyaCarMod] テクスチャ読み込み失敗: {} / {}", baseName, e.getMessage());
            cache.put(baseName, null);
            return null;
        }
    }
}