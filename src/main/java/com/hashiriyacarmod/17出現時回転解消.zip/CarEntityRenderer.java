package com.hashiriyacarmod;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;

@OnlyIn(Dist.CLIENT)
public class CarEntityRenderer extends EntityRenderer<CarEntity> {

    public CarEntityRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(CarEntity entity, float entityYaw, float partialTick,
                       PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {

        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);
        renderHitboxLines(entity, entityYaw, poseStack, bufferSource);

        if (!entity.resolveRenderCache()) return;

        var parts = entity.getCachedParts();
        if (parts.isEmpty()) return;

        ResourceLocation texLoc = entity.getCachedTextureLocation();
        if (texLoc == null) return;

        float carPitch = entity.getCarPitch();
        float carRoll = entity.getCarRoll();

        poseStack.pushPose();
        poseStack.mulPose(Axis.YP.rotationDegrees(-entity.getYRot()));
        poseStack.mulPose(Axis.XP.rotationDegrees(carPitch));
        poseStack.mulPose(Axis.ZP.rotationDegrees(carRoll));

        for (var entry : parts.entrySet()) {
            String partName = entry.getKey();
            ObjMesh mesh = entry.getValue();

            poseStack.pushPose();
            Matrix4f partMatrix = new Matrix4f(poseStack.last().pose());
            drawMeshOnGpu(entity, partName, mesh, partMatrix, texLoc, packedLight);
            poseStack.popPose();
        }

        poseStack.popPose();
        com.mojang.blaze3d.vertex.BufferUploader.invalidate();
    }
    /**
     * 1パーツ分を、独自バッファ(PartVertexBuffer)で描画します。
     * バッファ自体(座標・UV・法線・色)は使い回し、明るさが前回と違う時だけ
     * ピンポイント更新されます。座標・色・UV・法線を変えたい場合は、
     * CarEntity.updatePartColorIfChanged() 等を必要な箇所から呼び出してください。
     */
    private void drawMeshOnGpu(CarEntity entity, String partName, ObjMesh mesh,
                               Matrix4f partMatrix, ResourceLocation texLoc, int packedLight) {

        PartVertexBuffer buffer = entity.getOrCreatePartBuffer(partName, mesh, packedLight);
        if (buffer == null) return;

        entity.updatePartLightIfChanged(partName, buffer, packedLight);

        RenderType renderType = CarRenderTypes.entityCutoutTriangles(texLoc);
        renderType.setupRenderState();

        try {
            com.mojang.blaze3d.vertex.BufferUploader.invalidate();
            drawWithShaderManual(partMatrix, RenderSystem.getProjectionMatrix(),
                    RenderSystem.getShader(), buffer);
        } finally {
            com.mojang.blaze3d.vertex.BufferUploader.invalidate();
            renderType.clearRenderState();
        }
    }

    /**
     * VertexBuffer._drawWithShader() が本来行っていた
     * 「シェーダーへ行列・テクスチャ・fog等を渡す」処理を、
     * 独自バッファ(PartVertexBuffer)向けに最低限だけ再現したものです。
     */
    private void drawWithShaderManual(Matrix4f modelViewMatrix, Matrix4f projectionMatrix,
                                      ShaderInstance shader, PartVertexBuffer buffer) {
        if (shader == null) return;

        for (int i = 0; i < 12; ++i) {
            int texId = RenderSystem.getShaderTexture(i);
            shader.setSampler("Sampler" + i, texId);
        }

        if (shader.MODEL_VIEW_MATRIX != null) {
            shader.MODEL_VIEW_MATRIX.set(modelViewMatrix);
        }
        if (shader.PROJECTION_MATRIX != null) {
            shader.PROJECTION_MATRIX.set(projectionMatrix);
        }
        if (shader.INVERSE_VIEW_ROTATION_MATRIX != null) {
            shader.INVERSE_VIEW_ROTATION_MATRIX.set(RenderSystem.getInverseViewRotationMatrix());
        }
        if (shader.COLOR_MODULATOR != null) {
            shader.COLOR_MODULATOR.set(RenderSystem.getShaderColor());
        }
        if (shader.GLINT_ALPHA != null) {
            shader.GLINT_ALPHA.set(RenderSystem.getShaderGlintAlpha());
        }
        if (shader.FOG_START != null) {
            shader.FOG_START.set(RenderSystem.getShaderFogStart());
        }
        if (shader.FOG_END != null) {
            shader.FOG_END.set(RenderSystem.getShaderFogEnd());
        }
        if (shader.FOG_COLOR != null) {
            shader.FOG_COLOR.set(RenderSystem.getShaderFogColor());
        }
        if (shader.FOG_SHAPE != null) {
            shader.FOG_SHAPE.set(RenderSystem.getShaderFogShape().getIndex());
        }
        if (shader.TEXTURE_MATRIX != null) {
            shader.TEXTURE_MATRIX.set(RenderSystem.getTextureMatrix());
        }
        if (shader.GAME_TIME != null) {
            shader.GAME_TIME.set(RenderSystem.getShaderGameTime());
        }
        if (shader.SCREEN_SIZE != null) {
            var window = Minecraft.getInstance().getWindow();
            shader.SCREEN_SIZE.set((float) window.getWidth(), (float) window.getHeight());
        }

        RenderSystem.setupShaderLights(shader);
        shader.apply();
        buffer.draw();
        shader.clear();
    }

    private void renderHitboxLines(CarEntity entity, float entityYaw,
                                   PoseStack poseStack, MultiBufferSource bufferSource) {

        if (!Minecraft.getInstance().getEntityRenderDispatcher().shouldRenderHitBoxes()) return;

        var allBoxes = entity.getAllWorldHitboxVertices(entityYaw);
        if (allBoxes.isEmpty()) return;

        VertexConsumer lineConsumer = bufferSource.getBuffer(RenderType.lines());
        PoseStack.Pose pose = poseStack.last();

        int[][] edges = {
                {0, 1}, {1, 2}, {2, 3}, {3, 0},
                {4, 5}, {5, 6}, {6, 7}, {7, 4},
                {0, 4}, {1, 5}, {2, 6}, {3, 7}
        };

        // 箱ごとに、線を描画します
        for (Vec3[] worldVertices : allBoxes) {
            float[] relX = new float[8], relY = new float[8], relZ = new float[8];
            for (int i = 0; i < 8; i++) {
                relX[i] = (float) (worldVertices[i].x - entity.getX());
                relY[i] = (float) (worldVertices[i].y - entity.getY());
                relZ[i] = (float) (worldVertices[i].z - entity.getZ());
            }

            for (int[] edge : edges) {
                int a = edge[0], b = edge[1];
                lineConsumer.vertex(pose.pose(), relX[a], relY[a], relZ[a])
                        .color(0, 0, 255, 255)
                        .normal(pose.normal(), 0, 1, 0)
                        .endVertex();
                lineConsumer.vertex(pose.pose(), relX[b], relY[b], relZ[b])
                        .color(0, 0, 255, 255)
                        .normal(pose.normal(), 0, 1, 0)
                        .endVertex();
            }
        }
    }

    @Override
    public ResourceLocation getTextureLocation(CarEntity entity) {
        return new ResourceLocation(HashiriyaCarMod.MOD_ID, "textures/entity/placeholder.png");
    }
}