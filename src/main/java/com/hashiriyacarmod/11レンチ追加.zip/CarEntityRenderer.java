package com.hashiriyacarmod;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import org.joml.Matrix4f;

@OnlyIn(Dist.CLIENT)
public class CarEntityRenderer extends EntityRenderer<CarEntity> {

    public CarEntityRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(CarEntity entity, float entityYaw, float partialTick,
                       PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {

        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);

        // F3+Bが有効な場合、検知ボックスを線で表示します
        renderHitboxLines(entity, entityYaw, poseStack, bufferSource);

        if (!entity.resolveRenderCache()) return;

        var parts = entity.getCachedParts();
        if (parts.isEmpty()) return;

        ResourceLocation texLoc = entity.getCachedTextureLocation();
        if (texLoc == null) return;

        float carPitch = entity.getCarPitch();
        float carRoll = entity.getCarRoll();

        poseStack.pushPose();
        poseStack.mulPose(Axis.YP.rotationDegrees(-entityYaw));
        poseStack.mulPose(Axis.XP.rotationDegrees(carPitch));
        poseStack.mulPose(Axis.ZP.rotationDegrees(carRoll));

        for (var entry : parts.entrySet()) {
            String partName = entry.getKey();
            ObjMesh mesh = entry.getValue();

            poseStack.pushPose();
            // ← ここにパーツごとのアニメーションを書きます（後で実装）
            // 今後、"o"行の名前(partName)を見て特定パーツだけ回転させる場合、
            // ここでpartNameを判定してposeStackに回転を追加してください。

            Matrix4f partMatrix = new Matrix4f(poseStack.last().pose());
            drawMeshOnGpu(entity, partName, mesh, partMatrix, texLoc, packedLight);

            poseStack.popPose();
        }

        poseStack.popPose();
    }

    /**
     * 1パーツ分のメッシュを、GPU計算方式で描画します。
     *
     * 「形」(ローカル座標)はそのままバッファに詰めます。
     * 「行列」は、Minecraft標準のモデルビュー行列スタックに積んでおくことで、
     * 標準の頂点シェーダーがGPU側で座標変換を行います。
     * 独自シェーダーファイルは一切使いません。
     */
    private void drawMeshOnGpu(CarEntity entity, String partName, ObjMesh mesh,
                               Matrix4f partMatrix, ResourceLocation texLoc, int packedLight) {

        VertexBuffer vbo = entity.getOrCreatePartBuffer(partName, mesh, packedLight);
        if (vbo == null) return;

        RenderType renderType = CarRenderTypes.entityCutoutTriangles(texLoc);

        renderType.setupRenderState();

        vbo.bind();
        vbo.drawWithShader(partMatrix, RenderSystem.getProjectionMatrix(), RenderSystem.getShader());
        VertexBuffer.unbind();

        renderType.clearRenderState();
    }

    /**
     * F3+Bで表示される、標準のヒットボックス表示のオンオフ設定を流用し、
     * 検知ボックス（台形も含む8頂点の箱）を線で描画します。
     */
    private void renderHitboxLines(CarEntity entity, float entityYaw,
                                   PoseStack poseStack, MultiBufferSource bufferSource) {

        if (!Minecraft.getInstance().getEntityRenderDispatcher().shouldRenderHitBoxes()) return;

        Vec3[] worldVertices = entity.getWorldHitboxVertices(entityYaw);
        if (worldVertices == null) return;

        float[] relX = new float[8], relY = new float[8], relZ = new float[8];
        for (int i = 0; i < 8; i++) {
            relX[i] = (float) (worldVertices[i].x - entity.getX());
            relY[i] = (float) (worldVertices[i].y - entity.getY());
            relZ[i] = (float) (worldVertices[i].z - entity.getZ());
        }

        int[][] edges = {
                {0, 1}, {1, 2}, {2, 3}, {3, 0},
                {4, 5}, {5, 6}, {6, 7}, {7, 4},
                {0, 4}, {1, 5}, {2, 6}, {3, 7}
        };

        VertexConsumer lineConsumer = bufferSource.getBuffer(RenderType.lines());
        PoseStack.Pose pose = poseStack.last();

        for (int[] edge : edges) {
            int a = edge[0], b = edge[1];
            lineConsumer.vertex(pose.pose(), relX[a], relY[a], relZ[a])
                    .color(0, 0, 255, 255)
                    .normal(pose.normal(), 0, 1, 0)
                    .endVertex();
            lineConsumer.vertex(pose.pose(), relX[b], relY[b], relZ[b])
                    .color(0, 0, 255, 255)
                    .normal(pose.normal(), 0, 1, 0)
                    .endVertex();
        }
    }

    @Override
    public ResourceLocation getTextureLocation(CarEntity entity) {
        return new ResourceLocation(HashiriyaCarMod.MOD_ID, "textures/entity/placeholder.png");
    }
}