package com.hashiriyacarmod;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import org.lwjgl.opengl.GL15;
import org.lwjgl.opengl.GL20;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * 1パーツ分の頂点データを、GPU上に「項目ごとのかたまり」で保持するクラスです。
 *
 * 通常のMinecraftのVertexBufferは「頂点ごとに全項目をまとめて」並べますが、
 * このクラスは逆に「項目ごとに全頂点をまとめて」1本のバッファに並べます。
 *
 * これにより、座標・色・UV・明るさ・法線のうち「変わった項目だけ」を
 * ピンポイントで書き換えられます（他の項目は一切再送信しません）。
 *
 * バッファオブジェクト自体は最初に1回だけ作り、以後は同じ箱を使い回します。
 */
public class PartVertexBuffer implements AutoCloseable {

    // ---- 各項目のバイトサイズ（1頂点あたり） ----
    private static final int POS_SIZE    = 12; // float x3
    private static final int COLOR_SIZE  = 4;  // ubyte x4
    private static final int UV0_SIZE    = 8;  // float x2
    private static final int OVERLAY_SIZE = 4; // short x2
    private static final int LIGHT_SIZE  = 4;  // short x2
    private static final int NORMAL_SIZE = 4;  // byte x3 + パディング1

    // ---- attribute location（シェーダー側と要一致。仮に標準NEW_ENTITY順とする） ----
    private static final int LOC_POSITION = 0;
    private static final int LOC_COLOR    = 1;
    private static final int LOC_UV0      = 2;
    private static final int LOC_OVERLAY  = 3;
    private static final int LOC_LIGHT    = 4;
    private static final int LOC_NORMAL   = 5;

    private final int vao;
    private final int vbo;
    private final int ibo;
    private final int vertexCount;
    private final int indexCount;

    // ---- バッファ内での「かたまり」ごとの開始位置（オフセット） ----
    private final int offsetPos;
    private final int offsetColor;
    private final int offsetUv0;
    private final int offsetOverlay;
    private final int offsetLight;
    private final int offsetNormal;
    private final int totalSize;

    private int lastLight = -1;

    public PartVertexBuffer(ObjMesh mesh, int initialPackedLight) {
        this.vertexCount = mesh.vertexCount;
        this.indexCount = mesh.indexCount;

        // 各かたまりの位置を計算（項目ごとに全頂点ぶんまとめて並べる）
        this.offsetPos     = 0;
        this.offsetColor    = offsetPos     + vertexCount * POS_SIZE;
        this.offsetUv0      = offsetColor   + vertexCount * COLOR_SIZE;
        this.offsetOverlay  = offsetUv0     + vertexCount * UV0_SIZE;
        this.offsetLight    = offsetOverlay + vertexCount * OVERLAY_SIZE;
        this.offsetNormal   = offsetLight   + vertexCount * LIGHT_SIZE;
        this.totalSize      = offsetNormal  + vertexCount * NORMAL_SIZE;

        RenderSystem.assertOnRenderThread();
        this.vao = GlStateManager._glGenVertexArrays();
        this.vbo = GlStateManager._glGenBuffers();
        this.ibo = GlStateManager._glGenBuffers();

        GlStateManager._glBindVertexArray(vao);

        // ---------- 最初の全項目データを1本のバッファにまとめて詰める ----------
        ByteBuffer buf = ByteBuffer.allocateDirect(totalSize).order(ByteOrder.nativeOrder());

        // 座標のかたまり
        for (int i = 0; i < vertexCount; i++) {
            buf.putFloat(offsetPos + i * POS_SIZE,     mesh.posX[i]);
            buf.putFloat(offsetPos + i * POS_SIZE + 4, mesh.posY[i]);
            buf.putFloat(offsetPos + i * POS_SIZE + 8, mesh.posZ[i]);
        }
        // 色のかたまり（常に白固定、JSONで変える場合はここを可変にする）
        for (int i = 0; i < vertexCount; i++) {
            int p = offsetColor + i * COLOR_SIZE;
            buf.put(p,     (byte) 255);
            buf.put(p + 1, (byte) 255);
            buf.put(p + 2, (byte) 255);
            buf.put(p + 3, (byte) 255);
        }
        // UVのかたまり
        for (int i = 0; i < vertexCount; i++) {
            buf.putFloat(offsetUv0 + i * UV0_SIZE,     mesh.u[i]);
            buf.putFloat(offsetUv0 + i * UV0_SIZE + 4, mesh.v[i]);
        }
        // Overlayのかたまり（固定値：NO_OVERLAY相当 = 0xFFFF0000程度、環境に合わせて）
        for (int i = 0; i < vertexCount; i++) {
            int p = offsetOverlay + i * OVERLAY_SIZE;
            int noOverlay = net.minecraft.client.renderer.texture.OverlayTexture.NO_OVERLAY;
            short overlayU = (short) (noOverlay & 0xFFFF);
            short overlayV = (short) (noOverlay >> 16 & 0xFFFF);
            buf.putShort(p,     overlayU);
            buf.putShort(p + 2, overlayV);
        }
        // 明るさのかたまり
        writeLightInto(buf, initialPackedLight);
        // 法線のかたまり
        for (int i = 0; i < vertexCount; i++) {
            int p = offsetNormal + i * NORMAL_SIZE;
            buf.put(p,     floatToByteNormal(mesh.nx[i]));
            buf.put(p + 1, floatToByteNormal(mesh.ny[i]));
            buf.put(p + 2, floatToByteNormal(mesh.nz[i]));
            buf.put(p + 3, (byte) 0); // パディング
        }
        buf.rewind();

        GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        RenderSystem.glBufferData(GL15.GL_ARRAY_BUFFER, buf, GL15.GL_STATIC_DRAW);

        // ---------- attribute pointerの設定 ----------
        // SoAなので、各項目のstrideは「その項目自身のサイズ」でよい（頂点間の飛び幅がない）
        GL20.glVertexAttribPointer(LOC_POSITION, 3, GL20.GL_FLOAT, false, POS_SIZE, offsetPos);
        GL20.glEnableVertexAttribArray(LOC_POSITION);

        GL20.glVertexAttribPointer(LOC_COLOR, 4, GL20.GL_UNSIGNED_BYTE, true, COLOR_SIZE, offsetColor);
        GL20.glEnableVertexAttribArray(LOC_COLOR);

        GL20.glVertexAttribPointer(LOC_UV0, 2, GL20.GL_FLOAT, false, UV0_SIZE, offsetUv0);
        GL20.glEnableVertexAttribArray(LOC_UV0);

        org.lwjgl.opengl.GL30.glVertexAttribIPointer(LOC_OVERLAY, 2, GL20.GL_SHORT, OVERLAY_SIZE, offsetOverlay);
        GL20.glEnableVertexAttribArray(LOC_OVERLAY);

        org.lwjgl.opengl.GL30.glVertexAttribIPointer(LOC_LIGHT, 2, GL20.GL_SHORT, LIGHT_SIZE, offsetLight);
        GL20.glEnableVertexAttribArray(LOC_LIGHT);

        GL20.glVertexAttribPointer(LOC_NORMAL, 3, GL20.GL_BYTE, true, NORMAL_SIZE, offsetNormal);
        GL20.glEnableVertexAttribArray(LOC_NORMAL);

        // ---------- インデックスバッファ（形は固定なので1回だけ） ----------
        ByteBuffer idxBuf = ByteBuffer.allocateDirect(indexCount * 4).order(ByteOrder.nativeOrder());
        for (int idx : mesh.indices) idxBuf.putInt(idx);
        idxBuf.rewind();

        GlStateManager._glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, ibo);
        RenderSystem.glBufferData(GL15.GL_ELEMENT_ARRAY_BUFFER, idxBuf, GL15.GL_STATIC_DRAW);

        GlStateManager._glBindVertexArray(0);

        this.lastLight = initialPackedLight;
    }

    /** 明るさが変わった時だけ、明るさのかたまりだけをピンポイントで書き換えます。 */
    public void updateLight(int packedLight) {
        if (packedLight == lastLight) return; // 変化なし → 何もしない
        lastLight = packedLight;

        ByteBuffer buf = ByteBuffer.allocateDirect(vertexCount * LIGHT_SIZE).order(ByteOrder.nativeOrder());
        writeLightInto(buf, packedLight);
        buf.rewind();

        GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferSubData(GL15.GL_ARRAY_BUFFER, offsetLight, buf); // ★ ここだけ更新
    }

    private void writeLightInto(ByteBuffer buf, int packedLight) {
        short u2 = (short) (packedLight & 0xFFFF);
        short v2 = (short) (packedLight >> 16 & 0xFFFF);
        for (int i = 0; i < vertexCount; i++) {
            int p = offsetLight + i * LIGHT_SIZE;
            // writeLightIntoが全体バッファ用/明るさ専用バッファ用どちらでも動くよう相対書き込みにする
            int localP = (buf.capacity() == vertexCount * LIGHT_SIZE) ? i * LIGHT_SIZE : p;
            buf.putShort(localP,     u2);
            buf.putShort(localP + 2, v2);
        }
    }

    /**
     * 座標だけが変わった場合(JSONでこのパーツを動かす等)、
     * 座標のかたまりだけをピンポイントで書き換えます。他の項目には触れません。
     */
    public void updatePositions(float[] posX, float[] posY, float[] posZ) {
        ByteBuffer buf = ByteBuffer.allocateDirect(vertexCount * POS_SIZE).order(ByteOrder.nativeOrder());
        for (int i = 0; i < vertexCount; i++) {
            buf.putFloat(i * POS_SIZE,     posX[i]);
            buf.putFloat(i * POS_SIZE + 4, posY[i]);
            buf.putFloat(i * POS_SIZE + 8, posZ[i]);
        }
        buf.rewind();

        GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferSubData(GL15.GL_ARRAY_BUFFER, offsetPos, buf); // ★ 座標のかたまりだけ
    }

    /** 色だけをピンポイントで書き換えます（発光・色変え等）。 */
    public void updateColor(int r, int g, int b, int a) {
        ByteBuffer buf = ByteBuffer.allocateDirect(vertexCount * COLOR_SIZE).order(ByteOrder.nativeOrder());
        for (int i = 0; i < vertexCount; i++) {
            int p = i * COLOR_SIZE;
            buf.put(p, (byte) r).put(p + 1, (byte) g).put(p + 2, (byte) b).put(p + 3, (byte) a);
        }
        buf.rewind();

        GlStateManager._glBindBuffer(GL15.GL_ARRAY_BUFFER, vbo);
        GL15.glBufferSubData(GL15.GL_ARRAY_BUFFER, offsetColor, buf); // ★ 色のかたまりだけ
    }

    private static byte floatToByteNormal(float v) {
        return (byte) Math.round(v * 127.0f);
    }

    public void draw() {
        GlStateManager._glBindVertexArray(vao);
        GlStateManager._glBindBuffer(GL15.GL_ELEMENT_ARRAY_BUFFER, ibo);
        GL20.glDrawElements(GL20.GL_TRIANGLES, indexCount, GL20.GL_UNSIGNED_INT, 0);
        GlStateManager._glBindVertexArray(0);
    }

    @Override
    public void close() {
        RenderSystem.glDeleteBuffers(vbo);
        RenderSystem.glDeleteBuffers(ibo);
        GlStateManager._glDeleteVertexArrays(vao);
    }
}