package com.hashiriyacarmod;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class CarEntityRenderer extends EntityRenderer<CarEntity> {

    public CarEntityRenderer(EntityRendererProvider.Context context) {
        super(context);
    }

    @Override
    public void render(CarEntity entity, float entityYaw, float partialTick,
                       PoseStack poseStack, MultiBufferSource bufferSource, int packedLight) {

        super.render(entity, entityYaw, partialTick, poseStack, bufferSource, packedLight);

        // F3+Bが有効な場合、検知ボックスを線で表示します
        renderHitboxLines(entity, entityYaw, poseStack, bufferSource);

        if (!entity.resolveRenderCache()) return;

        var parts = entity.getCachedParts();
        if (parts.isEmpty()) return;

        ResourceLocation texLoc = entity.getCachedTextureLocation();
        if (texLoc == null) return;

        VertexConsumer consumer = bufferSource.getBuffer(CarRenderTypes.entityCutoutTriangles(texLoc));

        float carPitch = entity.getCarPitch();
        float carRoll = entity.getCarRoll();

        poseStack.pushPose();
        poseStack.mulPose(Axis.YP.rotationDegrees(-entityYaw));
        poseStack.mulPose(Axis.XP.rotationDegrees(carPitch));
        poseStack.mulPose(Axis.ZP.rotationDegrees(carRoll));

        for (var entry : parts.entrySet()) {
            ObjMesh mesh = entry.getValue();

            poseStack.pushPose();
            // ← ここにパーツごとのアニメーションを書きます（後で実装）
            PoseStack.Pose pose = poseStack.last();

            for (int i = 0; i < mesh.vertexCount; i++) {
                consumer.vertex(pose.pose(), mesh.posX[i], mesh.posY[i], mesh.posZ[i])
                        .color(255, 255, 255, 255)
                        .uv(mesh.u[i], mesh.v[i])
                        .overlayCoords(OverlayTexture.NO_OVERLAY)
                        .uv2(packedLight)
                        .normal(pose.normal(), mesh.nx[i], mesh.ny[i], mesh.nz[i])
                        .endVertex();
            }

            poseStack.popPose();
        }

        poseStack.popPose();
    }

    /**
     * F3+Bで表示される、標準のヒットボックス表示のオンオフ設定を流用し、
     * 検知ボックス（台形も含む8頂点の箱）を線で描画します。
     */
    private void renderHitboxLines(CarEntity entity, float entityYaw,
                                   PoseStack poseStack, MultiBufferSource bufferSource) {

        if (!Minecraft.getInstance().getEntityRenderDispatcher().shouldRenderHitBoxes()) return;

        Vec3[] worldVertices = entity.getWorldHitboxVertices(entityYaw);
        if (worldVertices == null) return;

        // poseStackはすでにentityの描画位置に来ているため、
        // entity自身の座標からの相対位置に直してから描画します
        float[] relX = new float[8], relY = new float[8], relZ = new float[8];
        for (int i = 0; i < 8; i++) {
            relX[i] = (float) (worldVertices[i].x - entity.getX());
            relY[i] = (float) (worldVertices[i].y - entity.getY());
            relZ[i] = (float) (worldVertices[i].z - entity.getZ());
        }

        int[][] edges = {
                {0, 1}, {1, 2}, {2, 3}, {3, 0}, // 下面の4辺
                {4, 5}, {5, 6}, {6, 7}, {7, 4}, // 上面の4辺
                {0, 4}, {1, 5}, {2, 6}, {3, 7}  // 縦の4辺
        };

        VertexConsumer lineConsumer = bufferSource.getBuffer(RenderType.lines());
        PoseStack.Pose pose = poseStack.last();

        for (int[] edge : edges) {
            int a = edge[0], b = edge[1];
            lineConsumer.vertex(pose.pose(), relX[a], relY[a], relZ[a])
                    .color(0, 0, 255, 255)   // ← 青色に変更
                    .normal(pose.normal(), 0, 1, 0)
                    .endVertex();
            lineConsumer.vertex(pose.pose(), relX[b], relY[b], relZ[b])
                    .color(0, 0, 255, 255)   // ← 青色に変更
                    .normal(pose.normal(), 0, 1, 0)
                    .endVertex();
        }
    }

    @Override
    public ResourceLocation getTextureLocation(CarEntity entity) {
        return new ResourceLocation(HashiriyaCarMod.MOD_ID, "textures/entity/placeholder.png");
    }
}