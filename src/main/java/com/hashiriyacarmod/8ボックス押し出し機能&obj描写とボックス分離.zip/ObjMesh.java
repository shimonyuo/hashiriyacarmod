package com.hashiriyacarmod;

/**
 * OBJファイルを解析した結果を保持するデータクラス。
 * 三角形単位にすでに展開済みのフラット配列で持つ。
 */
public class ObjMesh {

    /** 頂点の総数（三角形数 × 3） */
    public final int vertexCount;

    public final float[] posX, posY, posZ; // 頂点座標
    public final float[] u, v;             // UV座標
    public final float[] nx, ny, nz;       // 法線

    public ObjMesh(int vertexCount,
                   float[] posX, float[] posY, float[] posZ,
                   float[] u,    float[] v,
                   float[] nx,   float[] ny,   float[] nz) {
        this.vertexCount = vertexCount;
        this.posX = posX; this.posY = posY; this.posZ = posZ;
        this.u    = u;    this.v    = v;
        this.nx   = nx;   this.ny   = ny;   this.nz   = nz;
    }
}