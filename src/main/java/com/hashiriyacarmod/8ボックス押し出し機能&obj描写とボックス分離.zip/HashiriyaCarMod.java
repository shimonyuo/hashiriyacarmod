package com.hashiriyacarmod;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;

@Mod(HashiriyaCarMod.MOD_ID)
public class HashiriyaCarMod {

    public static final String MOD_ID = "hashiriyacarmod";

    public HashiriyaCarMod() {
        // JSONフォルダを読み込み、エンティティ・アイテム・タブを登録する
        CarPackLoader.initialize(FMLJavaModLoadingContext.get());
    }
}