package com.hashiriyacarmod;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;

import java.util.Map;

public class CarEntity extends Entity {

    private static final EntityDataAccessor<String> BASE_NAME =
            SynchedEntityData.defineId(CarEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Float> CAR_PITCH =
            SynchedEntityData.defineId(CarEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> CAR_ROLL =
            SynchedEntityData.defineId(CarEntity.class, EntityDataSerializers.FLOAT);

    // 1回のティックで押し出す量の上限です（大きすぎるとワープしたように見えるため）
    private static final double MAX_PUSH_PER_TICK = 0.5;

    public CarEntity(EntityType<?> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData() {
        this.entityData.define(BASE_NAME, "");
        this.entityData.define(CAR_PITCH, 0.0f);
        this.entityData.define(CAR_ROLL, 0.0f);
    }

    public String getBaseName() {
        return this.entityData.get(BASE_NAME);
    }

    public void setBaseName(String name) {
        this.entityData.set(BASE_NAME, name);
        if (this.level() != null && this.level().isClientSide()) {
            invalidateRenderCache();
        }
    }

    public float getCarPitch() {
        return this.entityData.get(CAR_PITCH);
    }

    public void setCarPitch(float pitch) {
        this.entityData.set(CAR_PITCH, pitch);
    }

    public float getCarRoll() {
        return this.entityData.get(CAR_ROLL);
    }

    public void setCarRoll(float roll) {
        this.entityData.set(CAR_ROLL, roll);
    }

    // ==================== 検知ボックス（hitbox）関連 ====================

    public HitboxDefinition getHitboxDefinition() {
        return CarPackLoader.getHitboxDefinition(getBaseName());
    }

    public Vec3[] getWorldHitboxVertices() {
        return getWorldHitboxVertices(this.getYRot());
    }

    public Vec3[] getWorldHitboxVertices(float yawDegrees) {
        HitboxDefinition def = getHitboxDefinition();
        if (def == null) return null;
        return def.toWorldVertices(getX(), getY(), getZ(), yawDegrees, getCarPitch(), getCarRoll());
    }

    // ==================== 押し出しのみ（サーバー側のみ） ====================

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide()) return;

        Vec3[] myVertices = getWorldHitboxVertices();
        if (myVertices == null) return;

        pushOutOverlaps(myVertices);
    }

    /**
     * 周囲との重なりを調べ、重なっている相手を押し出します。
     * ブロックとの重なりは検知しません（押し出しの解決はまた別の話になるため）。
     * エンティティとの重なりのみ、相手を反対側へ押し出します。
     */
    private void pushOutOverlaps(Vec3[] myVertices) {
        double minX = Double.MAX_VALUE, minY = Double.MAX_VALUE, minZ = Double.MAX_VALUE;
        double maxX = -Double.MAX_VALUE, maxY = -Double.MAX_VALUE, maxZ = -Double.MAX_VALUE;
        for (Vec3 v : myVertices) {
            minX = Math.min(minX, v.x); maxX = Math.max(maxX, v.x);
            minY = Math.min(minY, v.y); maxY = Math.max(maxY, v.y);
            minZ = Math.min(minZ, v.z); maxZ = Math.max(maxZ, v.z);
        }
        AABB broadPhase = new AABB(minX, minY, minZ, maxX, maxY, maxZ);

        for (Entity other : this.level().getEntities(this, broadPhase, e -> true)) {

            if (other instanceof CarEntity otherCar) {
                Vec3[] otherVertices = otherCar.getWorldHitboxVertices();
                if (otherVertices == null) continue;

                Vec3 mtv = CarCollisionUtil.computeMTV(myVertices, otherVertices);
                if (mtv != null) {
                    pushEntity(otherCar, clampPush(mtv.scale(0.5)));
                    pushEntity(this, clampPush(mtv.scale(-0.5)));
                }

            } else {
                Vec3 mtv = CarCollisionUtil.computeMTV(myVertices, other.getBoundingBox());
                if (mtv != null) {
                    pushEntity(other, clampPush(mtv));
                }
            }
        }
    }

    private Vec3 clampPush(Vec3 push) {
        double length = push.length();
        if (length > MAX_PUSH_PER_TICK) {
            return push.scale(MAX_PUSH_PER_TICK / length);
        }
        return push;
    }

    private void pushEntity(Entity target, Vec3 push) {
        if (push.lengthSqr() < 1.0E-9) return;

        target.setPos(target.getX() + push.x, target.getY() + push.y, target.getZ() + push.z);

        Vec3 currentMotion = target.getDeltaMovement();
        target.setDeltaMovement(currentMotion.add(push.scale(0.3)));
        target.hurtMarked = true;
    }

    // ==================== クライアント側専用の「引き出し」 ====================

    @OnlyIn(Dist.CLIENT)
    private ClientRenderData clientData;

    @OnlyIn(Dist.CLIENT)
    private static class ClientRenderData {
        Map<String, ObjMesh> parts = Map.of();
        ResourceLocation textureLocation = null;
        boolean resolved = false;
    }

    @OnlyIn(Dist.CLIENT)
    public boolean resolveRenderCache() {
        if (clientData == null) {
            clientData = new ClientRenderData();
        }
        if (clientData.resolved) return !clientData.parts.isEmpty();

        String baseName = getBaseName();
        if (baseName == null || baseName.isEmpty()) return false;

        AssetRegistry registry = CarPackLoader.getAssetRegistry(baseName);
        if (registry == null || registry.parts.isEmpty()) {
            clientData.resolved = true;
            return false;
        }

        clientData.parts = registry.parts;
        if (registry.pngFile != null) {
            clientData.textureLocation = CarTextureManager.getOrLoad(baseName, registry.pngFile);
        }
        clientData.resolved = true;
        return true;
    }

    @OnlyIn(Dist.CLIENT)
    public Map<String, ObjMesh> getCachedParts() {
        return clientData != null ? clientData.parts : Map.of();
    }

    @OnlyIn(Dist.CLIENT)
    public ResourceLocation getCachedTextureLocation() {
        return clientData != null ? clientData.textureLocation : null;
    }

    @OnlyIn(Dist.CLIENT)
    private void invalidateRenderCache() {
        clientData = null;
    }

    // ==================== データ保存 ====================

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        if (tag.contains("BaseName")) {
            setBaseName(tag.getString("BaseName"));
        }
        if (tag.contains("CarPitch")) {
            setCarPitch(tag.getFloat("CarPitch"));
        }
        if (tag.contains("CarRoll")) {
            setCarRoll(tag.getFloat("CarRoll"));
        }
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putString("BaseName", getBaseName());
        tag.putFloat("CarPitch", getCarPitch());
        tag.putFloat("CarRoll", getCarRoll());
    }
}