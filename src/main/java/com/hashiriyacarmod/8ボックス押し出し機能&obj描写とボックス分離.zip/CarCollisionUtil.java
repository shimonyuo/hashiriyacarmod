package com.hashiriyacarmod;

import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;

/**
 * 8頂点からなる箱どうし、または箱とMinecraft標準のAABB
 * （ブロックや、回転しない通常のエンティティが持つ直方体の判定範囲）が
 * 重なっているかどうかを判定します。
 *
 * さらに、重なっている場合に「どちらの方向に・どれだけ動かせば
 * 重なりが解消するか」という押し出しベクトル（MTV）も計算できます。
 */
public class CarCollisionUtil {

    private CarCollisionUtil() {}

    /** カスタム箱どうしが重なっているか判定します。 */
    public static boolean intersects(Vec3[] verticesA, Vec3[] verticesB) {
        return computeMTV(verticesA, verticesB) != null;
    }

    /** カスタム箱と、Minecraft標準のAABBが重なっているか判定します。 */
    public static boolean intersects(Vec3[] verticesA, AABB aabb) {
        return intersects(verticesA, aabbVertices(aabb));
    }

    /**
     * カスタム箱どうしの「押し出しベクトル」を計算します。
     *
     * 重なっていない場合は null を返します。
     * 重なっている場合は、「Aから見てBをこれだけ動かせば重ならなくなる」という
     * ベクトル（方向＋重なっている深さ）を返します。
     * （Aを反対方向に動かしたい場合は、このベクトルを反転させて使ってください）
     */
    public static Vec3 computeMTV(Vec3[] verticesA, Vec3[] verticesB) {
        Vec3[] normalsA = faceNormals(verticesA);
        Vec3[] normalsB = faceNormals(verticesB);
        Vec3[] edgesA = edgeDirections(verticesA);
        Vec3[] edgesB = edgeDirections(verticesB);

        List<Vec3> axes = new ArrayList<>();
        addAll(axes, normalsA);
        addAll(axes, normalsB);
        for (Vec3 ea : edgesA) {
            for (Vec3 eb : edgesB) {
                Vec3 cross = ea.cross(eb);
                if (cross.lengthSqr() > 1.0E-8) {
                    axes.add(cross.normalize());
                }
            }
        }

        double smallestOverlap = Double.MAX_VALUE;
        Vec3 smallestAxis = null;

        for (Vec3 axis : axes) {
            double[] rangeA = projectRange(axis, verticesA);
            double[] rangeB = projectRange(axis, verticesB);

            // この軸で「離れている」瞬間があれば、そもそも重なっていない
            if (rangeA[1] < rangeB[0] || rangeB[1] < rangeA[0]) {
                return null; // 分離できる軸が見つかった → 重なっていない
            }

            double overlap = Math.min(rangeA[1], rangeB[1]) - Math.max(rangeA[0], rangeB[0]);
            if (overlap < smallestOverlap) {
                smallestOverlap = overlap;
                smallestAxis = axis;
            }
        }

        if (smallestAxis == null) return Vec3.ZERO;

        // 押し出す向きを「Aの中心 → Bの中心」に揃えます
        Vec3 centerA = centerOf(verticesA);
        Vec3 centerB = centerOf(verticesB);
        Vec3 centerDiff = centerB.subtract(centerA);

        if (centerDiff.dot(smallestAxis) < 0) {
            smallestAxis = smallestAxis.scale(-1);
        }

        return smallestAxis.scale(smallestOverlap);
    }

    /**
     * カスタム箱とAABBの「押し出しベクトル」を計算します。
     * 重なっていなければ null です。
     */
    public static Vec3 computeMTV(Vec3[] verticesA, AABB aabb) {
        return computeMTV(verticesA, aabbVertices(aabb));
    }

    private static double[] projectRange(Vec3 axis, Vec3[] vertices) {
        double min = Double.MAX_VALUE, max = -Double.MAX_VALUE;
        for (Vec3 v : vertices) {
            double d = v.dot(axis);
            min = Math.min(min, d);
            max = Math.max(max, d);
        }
        return new double[]{min, max};
    }

    private static Vec3 centerOf(Vec3[] vertices) {
        double x = 0, y = 0, z = 0;
        for (Vec3 v : vertices) {
            x += v.x; y += v.y; z += v.z;
        }
        int n = vertices.length;
        return new Vec3(x / n, y / n, z / n);
    }

    private static void addAll(List<Vec3> list, Vec3[] arr) {
        for (Vec3 v : arr) {
            if (v.lengthSqr() > 1.0E-8) {
                list.add(v.normalize());
            }
        }
    }

    private static Vec3[] faceNormals(Vec3[] vertices) {
        int[][] faces = HitboxDefinition.faces();
        Vec3[] normals = new Vec3[faces.length];
        for (int i = 0; i < faces.length; i++) {
            Vec3 p0 = vertices[faces[i][0]];
            Vec3 p1 = vertices[faces[i][1]];
            Vec3 p2 = vertices[faces[i][2]];
            normals[i] = p1.subtract(p0).cross(p2.subtract(p0));
        }
        return normals;
    }

    /** 代表的な3方向の辺（0→1, 1→2, 0→4）を使います。 */
    private static Vec3[] edgeDirections(Vec3[] vertices) {
        return new Vec3[]{
                vertices[1].subtract(vertices[0]),
                vertices[2].subtract(vertices[1]),
                vertices[4].subtract(vertices[0])
        };
    }

    private static Vec3[] aabbVertices(AABB aabb) {
        return new Vec3[]{
                new Vec3(aabb.minX, aabb.minY, aabb.minZ),
                new Vec3(aabb.maxX, aabb.minY, aabb.minZ),
                new Vec3(aabb.maxX, aabb.minY, aabb.maxZ),
                new Vec3(aabb.minX, aabb.minY, aabb.maxZ),
                new Vec3(aabb.minX, aabb.maxY, aabb.minZ),
                new Vec3(aabb.maxX, aabb.maxY, aabb.minZ),
                new Vec3(aabb.maxX, aabb.maxY, aabb.maxZ),
                new Vec3(aabb.minX, aabb.maxY, aabb.maxZ)
        };
    }
}